export default function Log() {

  
  return <ol id="log">

  </ol>
}